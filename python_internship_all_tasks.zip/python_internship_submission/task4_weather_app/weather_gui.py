"""Task 4 - Basic Weather App (Advanced tier: tkinter GUI with icons and forecasts)."""

from __future__ import annotations

import io
import threading
import time
import tkinter as tk
from tkinter import ttk

import requests
from PIL import Image, ImageTk

import weather_core as wc

BG = "#f4f7fb"
CARD = "#ffffff"


class WeatherApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("Weather App")
        self.geometry("820x640")
        self.minsize(760, 600)
        self.configure(bg=BG)

        self.unit = "C"
        self.current: dict | None = None
        self.entries: list[dict] = []
        self.icon_cache: dict[str, ImageTk.PhotoImage] = {}
        self.busy = False

        self.city_var = tk.StringVar()
        self.error_var = tk.StringVar()
        self.unit_var = tk.StringVar(value="Switch to °F")

        self._build_ui()
        self.city_entry.focus_set()

    # ---------------------------------------------------------------- UI
    def _build_ui(self) -> None:
        top = tk.Frame(self, bg=BG)
        top.pack(fill="x", padx=16, pady=(16, 6))
        tk.Label(top, text="City or ZIP:", bg=BG, font=("Segoe UI", 11)).pack(side="left")
        self.city_entry = ttk.Entry(top, textvariable=self.city_var, width=28, font=("Segoe UI", 11))
        self.city_entry.pack(side="left", padx=8)
        self.city_entry.bind("<Return>", lambda _e: self.get_weather())
        ttk.Button(top, text="Get Weather", command=self.get_weather).pack(side="left", padx=4)
        ttk.Button(top, text="Use my location", command=self.use_my_location).pack(side="left", padx=4)
        ttk.Button(top, textvariable=self.unit_var, command=self.toggle_unit).pack(side="right")

        # Errors appear inside the window (not the terminal)
        self.error_label = tk.Label(self, textvariable=self.error_var, bg=BG, fg="#c0392b",
                                    font=("Segoe UI", 10, "bold"), wraplength=760, justify="left")
        self.error_label.pack(fill="x", padx=18)

        # Current conditions panel
        self.current_frame = tk.Frame(self, bg=CARD, highlightbackground="#dfe6ee", highlightthickness=1)
        self.current_frame.pack(fill="x", padx=16, pady=8)
        self.icon_label = tk.Label(self.current_frame, bg=CARD)
        self.icon_label.pack(side="left", padx=16, pady=8)
        info = tk.Frame(self.current_frame, bg=CARD)
        info.pack(side="left", fill="x", expand=True, pady=8)
        self.place_label = tk.Label(info, text="Search for a city to begin", bg=CARD,
                                    font=("Segoe UI", 16, "bold"), anchor="w")
        self.place_label.pack(fill="x")
        self.temp_label = tk.Label(info, text="", bg=CARD, font=("Segoe UI", 30, "bold"), anchor="w")
        self.temp_label.pack(fill="x")
        self.detail_label = tk.Label(info, text="", bg=CARD, font=("Segoe UI", 11), fg="#4a5a6a",
                                     anchor="w", justify="left")
        self.detail_label.pack(fill="x")

        # Hourly panel
        tk.Label(self, text="Next 6 hours", bg=BG, font=("Segoe UI", 12, "bold"), anchor="w"
                 ).pack(fill="x", padx=18, pady=(8, 0))
        self.hourly_frame = tk.Frame(self, bg=BG)
        self.hourly_frame.pack(fill="x", padx=16, pady=4)

        # Daily panel
        tk.Label(self, text="5-day forecast", bg=BG, font=("Segoe UI", 12, "bold"), anchor="w"
                 ).pack(fill="x", padx=18, pady=(8, 0))
        self.daily_frame = tk.Frame(self, bg=BG)
        self.daily_frame.pack(fill="x", padx=16, pady=4)

    # ------------------------------------------------------------ actions
    def show_error(self, message: str) -> None:
        self.error_var.set(message)

    def get_weather(self, location: str | None = None) -> None:
        if self.busy:
            return
        location = location if location is not None else self.city_var.get()
        try:
            location = wc.validate_location(location)
        except wc.WeatherError as err:
            self.show_error(str(err))
            return
        self.error_var.set("")
        self.busy = True
        self.place_label.config(text="Loading...")
        threading.Thread(target=self._fetch, args=(location,), daemon=True).start()

    def _fetch(self, location: str) -> None:
        """Network work runs off the UI thread so the window never freezes."""
        try:
            key = wc.get_api_key()
            current = wc.fetch_current(location, key)
            entries = wc.fetch_forecast(location, key)
            icons = {i: self._download_icon(i) for i in self._needed_icons(current, entries)}
            self.after(0, self._on_success, current, entries, icons)
        except wc.WeatherError as err:
            self.after(0, self._on_error, str(err))
        except Exception as exc:  # last-resort guard so the UI always recovers
            self.after(0, self._on_error, f"Unexpected error: {exc}")

    def _needed_icons(self, current: dict, entries: list[dict]) -> set[str]:
        needed = {current["icon"]}
        needed |= {e["icon"] for e in wc.hourly_slots(entries, time.time())}
        needed |= {d["icon"] for d in wc.daily_summary(entries)}
        return needed

    def _download_icon(self, code: str) -> bytes | None:
        try:
            resp = requests.get(wc.ICON_URL.format(icon=code), timeout=wc.TIMEOUT)
            resp.raise_for_status()
            return resp.content
        except requests.RequestException:
            return None

    def _on_error(self, message: str) -> None:
        self.busy = False
        self.place_label.config(text="Search for a city to begin" if self.current is None
                                else self._place_text())
        self.show_error(message)

    def _on_success(self, current: dict, entries: list[dict], icons: dict[str, bytes | None]) -> None:
        self.busy = False
        self.current, self.entries = current, entries
        for code, raw in icons.items():
            if raw and code not in self.icon_cache:
                image = Image.open(io.BytesIO(raw)).convert("RGBA")
                self.icon_cache[code] = ImageTk.PhotoImage(image)
        self.render()

    def use_my_location(self) -> None:
        if self.busy:
            return
        try:
            city = wc.detect_city_by_ip()
        except wc.WeatherError as err:
            self.show_error(str(err))
            return
        self.city_var.set(city)
        self.get_weather(city)

    def toggle_unit(self) -> None:
        self.unit = "F" if self.unit == "C" else "C"
        self.unit_var.set("Switch to °C" if self.unit == "F" else "Switch to °F")
        if self.current:
            self.render()

    # ---------------------------------------------------------- rendering
    def _place_text(self) -> str:
        c = self.current or {}
        return f"{c.get('city', '')}, {c.get('country', '')}".strip(", ")

    def _icon(self, code: str, fallback_size: int = 0):
        return self.icon_cache.get(code)

    def render(self) -> None:
        c = self.current
        if not c:
            return
        u = self.unit
        self.place_label.config(text=self._place_text())
        self.temp_label.config(text=wc.format_temp(c["temp_c"], u))
        wind = f"{wc.ms_to_mph(c['wind_ms']):.1f} mph" if u == "F" else f"{c['wind_ms']:.1f} m/s"
        self.detail_label.config(
            text=f"{c['description']}\nFeels like {wc.format_temp(c['feels_c'], u)}   |   "
                 f"Humidity {c['humidity']}%   |   Wind {wind}")
        icon = self._icon(c["icon"])
        self.icon_label.config(image=icon if icon else "", text="" if icon else c["description"])
        self.icon_label.image = icon

        for frame in (self.hourly_frame, self.daily_frame):
            for child in frame.winfo_children():
                child.destroy()

        for slot in wc.hourly_slots(self.entries, time.time()):
            self._tile(self.hourly_frame, wc.local_time(slot).strftime("%I:%M %p").lstrip("0"),
                       slot["icon"], wc.format_temp(slot["temp_c"], u), slot["description"])

        for day in wc.daily_summary(self.entries):
            temps = f"{wc.format_temp(day['max_c'], u)} / {wc.format_temp(day['min_c'], u)}"
            self._tile(self.daily_frame, day["date"].strftime("%a %d"), day["icon"], temps,
                       day["description"])

    def _tile(self, parent: tk.Frame, title: str, icon_code: str, temp: str, desc: str) -> None:
        tile = tk.Frame(parent, bg=CARD, highlightbackground="#dfe6ee", highlightthickness=1)
        tile.pack(side="left", fill="both", expand=True, padx=4)
        tk.Label(tile, text=title, bg=CARD, font=("Segoe UI", 10, "bold")).pack(pady=(6, 0))
        icon = self._icon(icon_code)
        lbl = tk.Label(tile, bg=CARD, image=icon if icon else "")
        lbl.image = icon
        lbl.pack()
        tk.Label(tile, text=temp, bg=CARD, font=("Segoe UI", 11, "bold")).pack()
        tk.Label(tile, text=desc, bg=CARD, fg="#4a5a6a", font=("Segoe UI", 8), wraplength=110
                 ).pack(pady=(0, 6))


if __name__ == "__main__":
    WeatherApp().mainloop()
