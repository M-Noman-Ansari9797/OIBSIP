# Task 4 – Basic Weather App (Python)

Fetches and displays real-time weather for any city or ZIP code using the OpenWeatherMap free
API. Both tiers are included: a **command-line** app (Beginner) and a **tkinter GUI** with
icons, hourly and 5-day forecasts and a unit toggle (Advanced).

## Features

### Beginner tier – `weather_cli.py`
- Prompts for a city name or ZIP code (`10001`, or `44000,PK` to give a country)
- Calls the OpenWeatherMap API and parses the JSON response
- Displays temperature in **°C and °F**, feels-like, **humidity %**, a weather description
  (e.g. "Partly Cloudy") and **wind speed**
- Handles errors gracefully: city not found, network timeout, no connection, invalid API key,
  rate limit (HTTP 429), server errors, malformed responses
- Rejects empty input

### Advanced tier – `weather_gui.py`
- Window with a city field, **Get Weather** button and results panel
- **Weather icons** loaded from OpenWeatherMap icon URLs (Pillow)
- **Hourly forecast** panel for the next 6 hours
- **Daily forecast** panel for the next 5 days (min/max temperature, dominant condition)
- **°C / °F toggle** that re-renders instantly without another API call
- **Bonus:** "Use my location" detects the city from your IP address via ipinfo.io
- All error messages are shown **inside the window** – nothing is printed to the terminal
- Network calls run on a background thread so the window never freezes

## Setup

1. Create a free account at <https://openweathermap.org> and copy your API key
   (new keys can take up to ~2 hours to activate).
2. Install dependencies and set the key as an environment variable (never hard-code it):

```bash
pip install -r requirements.txt

# Windows (then reopen the terminal)
setx OPENWEATHER_API_KEY "your_key_here"

# macOS / Linux
export OPENWEATHER_API_KEY="your_key_here"
```

3. Run:

```bash
python weather_cli.py      # Beginner
python weather_gui.py      # Advanced
```
Optional: `DEFAULT_COUNTRY` (default `US`) sets the country used for ZIP codes entered without one.

## Design notes
- `weather_core.py` contains all API, parsing and conversion logic, shared by both versions.
- **Hourly forecast:** the free OpenWeatherMap plan provides forecasts in **3-hour steps**
  (`/forecast` endpoint), so "next 6 hours" is shown as the upcoming 3-hour slots that start
  within that window (always at least two). True hourly data needs a paid plan.
- **Daily forecast** is built by grouping the 3-hour entries by the city's local date.
- The free tier allows 60 calls/minute, which this app stays well below.

## Testing
```bash
python -m unittest test_weather -v
```
18 tests run **without a network or API key** by mocking HTTP calls. They cover location/ZIP
parsing, unit conversion, JSON parsing, hourly/daily aggregation, every error path
(404, 401, 429, 500, timeout, connection failure, missing key) and IP detection.

## Project structure
```
task4_weather_app/
├── weather_core.py      API client, parsing, conversions
├── weather_cli.py       Beginner tier
├── weather_gui.py       Advanced tier
├── test_weather.py      unit tests (mocked network)
├── requirements.txt
└── README.md
```
