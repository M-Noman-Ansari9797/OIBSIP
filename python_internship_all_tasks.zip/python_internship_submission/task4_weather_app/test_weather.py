"""Unit tests for the weather logic. Network calls are mocked - no API key is needed."""
import unittest
from unittest import mock

import requests

import weather_core as wc

CURRENT_JSON = {
    "name": "Islamabad", "sys": {"country": "PK"}, "coord": {"lat": 33.7, "lon": 73.0},
    "main": {"temp": 25.4, "feels_like": 26.1, "humidity": 48},
    "weather": [{"description": "partly cloudy", "icon": "03d", "main": "Clouds"}],
    "wind": {"speed": 3.5},
}


def make_forecast(start_ts=1_800_000_000, steps=40, tz=18000):
    items = []
    for i in range(steps):
        items.append({
            "dt": start_ts + i * 10800,
            "main": {"temp": 20 + (i % 8)},
            "weather": [{"description": "clear sky" if i % 2 else "light rain",
                         "main": "Clear" if i % 2 else "Rain",
                         "icon": "01d" if i % 2 else "10n"}],
            "pop": 0.1,
        })
    return {"list": items, "city": {"timezone": tz}}


def fake_response(status=200, payload=None):
    resp = mock.Mock()
    resp.status_code = status
    resp.ok = 200 <= status < 300
    resp.json.return_value = payload if payload is not None else {}
    return resp


class LocationTests(unittest.TestCase):
    def test_city(self):
        self.assertEqual(wc.location_params("Lahore"), {"q": "Lahore"})
        self.assertEqual(wc.location_params("London,GB"), {"q": "London,GB"})

    def test_zip(self):
        self.assertEqual(wc.location_params("10001"), {"zip": "10001,US"})
        self.assertEqual(wc.location_params("44000, pk"), {"zip": "44000,PK"})

    def test_empty_rejected(self):
        for bad in ("", "   ", None):
            with self.assertRaises(wc.WeatherError):
                wc.validate_location(bad)


class ConversionTests(unittest.TestCase):
    def test_conversions(self):
        self.assertAlmostEqual(wc.c_to_f(0), 32)
        self.assertAlmostEqual(wc.c_to_f(100), 212)
        self.assertAlmostEqual(wc.ms_to_mph(10), 22.3694, places=3)
        self.assertEqual(wc.format_temp(25, "C"), "25°C")
        self.assertEqual(wc.format_temp(25, "F"), "77°F")


class ParsingTests(unittest.TestCase):
    def test_parse_current(self):
        info = wc.parse_current(CURRENT_JSON)
        self.assertEqual(info["city"], "Islamabad")
        self.assertEqual(info["description"], "Partly Cloudy")
        self.assertEqual(info["humidity"], 48)
        self.assertAlmostEqual(info["wind_ms"], 3.5)

    def test_incomplete_current(self):
        with self.assertRaises(wc.WeatherError):
            wc.parse_current({"name": "X"})

    def test_hourly_slots(self):
        entries = wc.parse_forecast_entries(make_forecast())
        now = entries[0]["dt"] - 1800
        slots = wc.hourly_slots(entries, now)
        self.assertGreaterEqual(len(slots), 2)
        self.assertLessEqual(slots[-1]["dt"], now + 6 * 3600)

    def test_daily_summary_has_at_most_five_days(self):
        entries = wc.parse_forecast_entries(make_forecast())
        days = wc.daily_summary(entries)
        self.assertLessEqual(len(days), 5)
        self.assertGreaterEqual(len(days), 4)
        for d in days:
            self.assertLessEqual(d["min_c"], d["max_c"])
            self.assertTrue(d["icon"].endswith("d"))


class ApiErrorTests(unittest.TestCase):
    def call(self, response=None, side_effect=None):
        with mock.patch("weather_core.requests.get", return_value=response, side_effect=side_effect):
            return wc.fetch_current("Lahore", api_key="dummy")

    def test_success(self):
        self.assertEqual(self.call(fake_response(200, CURRENT_JSON))["city"], "Islamabad")

    def test_city_not_found(self):
        with self.assertRaisesRegex(wc.WeatherError, "not found"):
            self.call(fake_response(404))

    def test_invalid_key(self):
        with self.assertRaisesRegex(wc.WeatherError, "Invalid API key"):
            self.call(fake_response(401))

    def test_rate_limit(self):
        with self.assertRaisesRegex(wc.WeatherError, "Too many"):
            self.call(fake_response(429))

    def test_timeout(self):
        with self.assertRaisesRegex(wc.WeatherError, "timed out"):
            self.call(side_effect=requests.Timeout())

    def test_network_down(self):
        with self.assertRaisesRegex(wc.WeatherError, "Network error"):
            self.call(side_effect=requests.ConnectionError())

    def test_server_error(self):
        with self.assertRaisesRegex(wc.WeatherError, "HTTP 500"):
            self.call(fake_response(500))

    def test_missing_key(self):
        with mock.patch.dict("os.environ", {"OPENWEATHER_API_KEY": ""}):
            with self.assertRaisesRegex(wc.WeatherError, "API key"):
                wc.get_api_key()


class IpDetectionTests(unittest.TestCase):
    def test_detects_city(self):
        with mock.patch("weather_core.requests.get", return_value=mock.Mock(
                raise_for_status=lambda: None, json=lambda: {"city": "Rawalpindi"})):
            self.assertEqual(wc.detect_city_by_ip(), "Rawalpindi")

    def test_failure(self):
        with mock.patch("weather_core.requests.get", side_effect=requests.ConnectionError()):
            with self.assertRaises(wc.WeatherError):
                wc.detect_city_by_ip()


if __name__ == "__main__":
    unittest.main()
