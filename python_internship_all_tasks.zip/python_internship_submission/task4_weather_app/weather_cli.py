"""Task 4 - Basic Weather App (Beginner tier: command line)."""

from weather_core import WeatherError, c_to_f, fetch_current, get_api_key, ms_to_mph


def show_weather(info: dict) -> None:
    place = f"{info['city']}, {info['country']}" if info["country"] else info["city"]
    print(f"\nWeather in {place}")
    print("-" * (len(place) + 11))
    print(f"Condition   : {info['description']}")
    print(f"Temperature : {info['temp_c']:.1f} °C  /  {c_to_f(info['temp_c']):.1f} °F")
    print(f"Feels like  : {info['feels_c']:.1f} °C  /  {c_to_f(info['feels_c']):.1f} °F")
    print(f"Humidity    : {info['humidity']} %")
    print(f"Wind speed  : {info['wind_ms']:.1f} m/s  ({ms_to_mph(info['wind_ms']):.1f} mph)\n")


def main() -> None:
    print("=== Weather App ===")
    try:
        api_key = get_api_key()
    except WeatherError as err:
        print(f"Error: {err}")
        return

    while True:
        location = input("Enter a city name or ZIP code (or 'q' to quit): ").strip()
        if location.lower() in ("q", "quit", "exit"):
            print("Goodbye!")
            return
        try:
            show_weather(fetch_current(location, api_key))
        except WeatherError as err:
            print(f"  Error: {err}\n")


if __name__ == "__main__":
    try:
        main()
    except (KeyboardInterrupt, EOFError):
        print("\nProgram closed.")
