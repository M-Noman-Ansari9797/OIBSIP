"""OpenWeatherMap client and data helpers shared by the CLI and GUI versions."""

from __future__ import annotations

import os
import re
from collections import Counter, defaultdict
from datetime import datetime, timezone
from typing import Any

import requests

BASE_URL = "https://api.openweathermap.org/data/2.5"
ICON_URL = "https://openweathermap.org/img/wn/{icon}@2x.png"
IPINFO_URL = "https://ipinfo.io/json"
TIMEOUT = 8
DEFAULT_COUNTRY = os.getenv("DEFAULT_COUNTRY", "US")

ZIP_PATTERN = re.compile(r"^\s*(\d{4,10})\s*(?:,\s*([A-Za-z]{2}))?\s*$")


class WeatherError(Exception):
    """Any failure fetching or interpreting weather data, with a user-friendly message."""


def get_api_key() -> str:
    key = os.getenv("OPENWEATHER_API_KEY", "").strip()
    if not key:
        raise WeatherError(
            "No API key found. Set the OPENWEATHER_API_KEY environment variable "
            "(free key at openweathermap.org)."
        )
    return key


def validate_location(text: str) -> str:
    text = (text or "").strip()
    if not text:
        raise WeatherError("Please enter a city name or ZIP code.")
    if len(text) > 100:
        raise WeatherError("That location is too long.")
    return text


def location_params(location: str) -> dict[str, str]:
    """Return query params for a city name ('Lahore', 'London,GB') or ZIP ('10001' / '44000,PK')."""
    location = validate_location(location)
    zip_match = ZIP_PATTERN.match(location)
    if zip_match:
        country = (zip_match.group(2) or DEFAULT_COUNTRY).upper()
        return {"zip": f"{zip_match.group(1)},{country}"}
    return {"q": location}


def _request(endpoint: str, params: dict[str, str], api_key: str) -> dict[str, Any]:
    query = {**params, "appid": api_key, "units": "metric"}
    try:
        response = requests.get(f"{BASE_URL}/{endpoint}", params=query, timeout=TIMEOUT)
    except requests.Timeout:
        raise WeatherError("The request timed out. Check your connection and try again.") from None
    except requests.ConnectionError:
        raise WeatherError("Network error - could not reach the weather service.") from None
    except requests.RequestException as exc:
        raise WeatherError(f"Unexpected network problem: {exc}") from None

    if response.status_code == 401:
        raise WeatherError("Invalid API key. New keys can take up to a couple of hours to activate.")
    if response.status_code == 404:
        raise WeatherError("City or ZIP code not found. Check the spelling and try again.")
    if response.status_code == 429:
        raise WeatherError("Too many requests - the free plan allows 60 calls per minute.")
    if not response.ok:
        raise WeatherError(f"Weather service error (HTTP {response.status_code}).")
    try:
        return response.json()
    except ValueError:
        raise WeatherError("The weather service returned an unreadable response.") from None


# ---------------------------------------------------------------- conversions
def c_to_f(celsius: float) -> float:
    return celsius * 9 / 5 + 32


def ms_to_mph(speed: float) -> float:
    return speed * 2.23694


def format_temp(celsius: float, unit: str) -> str:
    return f"{c_to_f(celsius):.0f}°F" if unit == "F" else f"{celsius:.0f}°C"


# -------------------------------------------------------------------- parsing
def parse_current(data: dict[str, Any]) -> dict[str, Any]:
    try:
        return {
            "city": data["name"],
            "country": data.get("sys", {}).get("country", ""),
            "temp_c": float(data["main"]["temp"]),
            "feels_c": float(data["main"].get("feels_like", data["main"]["temp"])),
            "humidity": int(data["main"]["humidity"]),
            "description": data["weather"][0]["description"].title(),
            "icon": data["weather"][0]["icon"],
            "wind_ms": float(data.get("wind", {}).get("speed", 0.0)),
            "lat": data.get("coord", {}).get("lat"),
            "lon": data.get("coord", {}).get("lon"),
        }
    except (KeyError, IndexError, TypeError, ValueError):
        raise WeatherError("The weather data was incomplete. Please try again.") from None


def parse_forecast_entries(data: dict[str, Any]) -> list[dict[str, Any]]:
    try:
        entries = []
        for item in data["list"]:
            entries.append({
                "dt": int(item["dt"]),
                "temp_c": float(item["main"]["temp"]),
                "description": item["weather"][0]["description"].title(),
                "main": item["weather"][0]["main"],
                "icon": item["weather"][0]["icon"],
                "pop": float(item.get("pop", 0)),
            })
        tz_offset = int(data.get("city", {}).get("timezone", 0))
    except (KeyError, IndexError, TypeError, ValueError):
        raise WeatherError("The forecast data was incomplete. Please try again.") from None
    for e in entries:
        e["tz_offset"] = tz_offset
    return entries


def local_time(entry: dict[str, Any]) -> datetime:
    """Entry time in the forecast city's own time zone (as a naive datetime)."""
    return datetime.fromtimestamp(entry["dt"] + entry["tz_offset"], tz=timezone.utc).replace(tzinfo=None)


def hourly_slots(entries: list[dict[str, Any]], now_ts: float, hours: int = 6) -> list[dict[str, Any]]:
    """Forecast slots covering the next `hours` hours.

    The free OpenWeatherMap forecast has 3-hour steps, so 'next 6 hours' is shown as the
    upcoming 3-hour slots that start within that window (always at least two).
    """
    upcoming = [e for e in entries if e["dt"] >= now_ts - 3600]
    within = [e for e in upcoming if e["dt"] <= now_ts + hours * 3600]
    return within if len(within) >= 2 else upcoming[:2]


def daily_summary(entries: list[dict[str, Any]], days: int = 5) -> list[dict[str, Any]]:
    """Collapse 3-hourly entries into per-day min/max, dominant condition and icon."""
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for entry in entries:
        grouped[local_time(entry).strftime("%Y-%m-%d")].append(entry)

    summary = []
    for date_key in sorted(grouped)[:days]:
        items = grouped[date_key]
        conditions = Counter(i["main"] for i in items)
        dominant = conditions.most_common(1)[0][0]
        # Use the entry closest to midday that matches the dominant condition for the icon.
        candidates = [i for i in items if i["main"] == dominant]
        rep = min(candidates, key=lambda i: abs(local_time(i).hour - 12))
        summary.append({
            "date": datetime.strptime(date_key, "%Y-%m-%d"),
            "min_c": min(i["temp_c"] for i in items),
            "max_c": max(i["temp_c"] for i in items),
            "description": rep["description"],
            "icon": rep["icon"].replace("n", "d"),   # daytime icon reads better in a daily view
        })
    return summary


# ------------------------------------------------------------------ public API
def fetch_current(location: str, api_key: str | None = None) -> dict[str, Any]:
    return parse_current(_request("weather", location_params(location), api_key or get_api_key()))


def fetch_forecast(location: str, api_key: str | None = None) -> list[dict[str, Any]]:
    return parse_forecast_entries(_request("forecast", location_params(location), api_key or get_api_key()))


def detect_city_by_ip() -> str:
    """Bonus: approximate city from the public IP address via ipinfo.io (free tier)."""
    try:
        response = requests.get(IPINFO_URL, timeout=TIMEOUT)
        response.raise_for_status()
        city = response.json().get("city", "").strip()
    except (requests.RequestException, ValueError):
        raise WeatherError("Could not detect your location automatically.") from None
    if not city:
        raise WeatherError("Could not detect your location automatically.")
    return city
